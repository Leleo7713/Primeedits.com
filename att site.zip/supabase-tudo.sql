-- PRIME EDITS: cole tudo no Supabase > SQL Editor > Run.
-- ANTES: troque SEU-EMAIL@exemplo.com pelo e-mail da sua conta de administrador.

create table if not exists admins(email text primary key);
insert into admins(email) values ('SEU-EMAIL@exemplo.com') on conflict do nothing;

create or replace function is_admin() returns boolean language sql stable security definer set search_path=public as
$$ select exists(select 1 from admins where lower(email)=lower(coalesce(auth.jwt()->>'email',''))) $$;

create table if not exists settings(key text primary key, value text);
create table if not exists products(id int primary key, name text, price numeric, short text, "full" text, active boolean default true);
create table if not exists orders(id bigint generated always as identity primary key, user_id uuid references auth.users, email text, name text, phone text,
  items jsonb, total numeric, status text not null default 'pending' check(status in('pending','paid','rejected')), created_at timestamptz default now());
create table if not exists reviews(id bigint generated always as identity primary key, user_id uuid references auth.users, order_id bigint references orders(id) on delete set null, name text, stars int check(stars between 1 and 5),
  text text, created_at timestamptz default now());
-- Uma avaliação por pedido (também atualiza bancos antigos)
alter table reviews add column if not exists order_id bigint references orders(id) on delete set null;
alter table reviews drop constraint if exists reviews_user_id_key;
create unique index if not exists reviews_um_por_pedido on reviews(order_id);
create table if not exists clientes(user_id uuid primary key references auth.users on delete cascade, email text, name text, since timestamptz default now());

alter table admins enable row level security; alter table settings enable row level security; alter table products enable row level security;
alter table orders enable row level security; alter table reviews enable row level security; alter table clientes enable row level security;

drop policy if exists "admins le" on admins;
drop policy if exists "settings leitura" on settings; drop policy if exists "settings admin" on settings;
drop policy if exists "products leitura" on products; drop policy if exists "products admin" on products;
drop policy if exists "orders cliente le" on orders; drop policy if exists "orders cliente cria" on orders; drop policy if exists "orders admin" on orders;
drop policy if exists "reviews leitura" on reviews; drop policy if exists "reviews so quem pagou" on reviews; drop policy if exists "reviews so cliente" on reviews;
drop policy if exists "reviews cliente apaga" on reviews; drop policy if exists "reviews admin" on reviews;
drop policy if exists "clientes ve o proprio" on clientes; drop policy if exists "clientes admin" on clientes;

create policy "admins le" on admins for select using (is_admin());
create policy "settings leitura" on settings for select using (true);
create policy "settings admin" on settings for all using (is_admin()) with check (is_admin());
create policy "products leitura" on products for select using (true);
create policy "products admin" on products for all using (is_admin()) with check (is_admin());
create policy "orders cliente le" on orders for select using (auth.uid()=user_id);
create policy "orders cliente cria" on orders for insert with check (auth.uid()=user_id and status='pending');
create policy "orders admin" on orders for all using (is_admin()) with check (is_admin());
create policy "reviews leitura" on reviews for select using (true);
create policy "reviews so cliente" on reviews for insert with check (auth.uid()=user_id and order_id is not null and exists(select 1 from orders o where o.id=order_id and o.user_id=auth.uid() and o.status='paid'));
create policy "reviews cliente apaga" on reviews for delete using (auth.uid()=user_id);
create policy "reviews admin" on reviews for all using (is_admin()) with check (is_admin());
create policy "clientes ve o proprio" on clientes for select using (auth.uid()=user_id);
create policy "clientes admin" on clientes for all using (is_admin()) with check (is_admin());

-- Confirmou o pedido (paid) -> ganha o cargo CLIENTE. Sem nenhum pedido pago -> perde o cargo.
create or replace function sync_cliente() returns trigger language plpgsql security definer set search_path=public as $$
declare uid uuid := coalesce(new.user_id, old.user_id);
begin
  if uid is null then return coalesce(new,old); end if;
  if exists(select 1 from orders where user_id=uid and status='paid') then
    insert into clientes(user_id,email,name) select uid, o.email, o.name from orders o where o.user_id=uid and o.status='paid' order by o.created_at limit 1 on conflict do nothing;
  else delete from clientes where user_id=uid; end if;
  return coalesce(new,old);
end $$;
drop trigger if exists trg_cliente on orders;
create trigger trg_cliente after insert or update of status or delete on orders for each row execute function sync_cliente();

insert into clientes(user_id,email,name) select distinct on (user_id) user_id,email,name from orders where status='paid' and user_id is not null order by user_id, created_at on conflict do nothing;
